<?php


$filmovi = [

    "Sinners",
    "Black Bag",
    "Friendship", 
    "Wallace & Gromit: Vengeance Most Fowl",
    "Eephus",
    "The Annihilation of Fish", 
    "Caught by the Tides",
    "Presence",
    "The Last Showgirl",
    "I’m Still Here",
];
        
    echo "Ovo je jedan od mojih omiljenih filmova {$filmovi[7]}";

