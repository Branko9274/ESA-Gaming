<?php

$ceneProizvoda = [325, 458, 333, 891, 753, 642, 841];

$zbir = 0;
foreach($ceneProizvoda as $a){
    $zbir += $a;
}
echo $zbir;

//sabrano da je u pitanju niz od 7 cifara. 
echo count($ceneProizvoda);



// kako sabrati da nije ovoliki niz?? (nisam mogao naci resenje i nacin)
//$ukupno  = $ceneProizvoda[0] + $ceneProizvoda[1] + $ceneProizvoda[2] + $ceneProizvoda[3] + $ceneProizvoda[4] + $ceneProizvoda[5] + $ceneProizvoda[6] + $ceneProizvoda[7];


//echo $ukupno;