<?php

$osobe = [
    "Marko" => [
        "nadimak" => "Mare",
        "telefon" => 38165123456, 
    ],

    "Petar" =>[
        "nadimak" => "Pera", 
        "telefon" => 38164123456,
    ],

    "Budimir" =>[
        "nadimak" => "Buda",
        "telefon" => 38163123456,
    ],
 ];

 echo "Zovem {$osobe['Marko']['nadimak']} i njegov broj je {$osobe ['Marko']['telefon']}";
 
 