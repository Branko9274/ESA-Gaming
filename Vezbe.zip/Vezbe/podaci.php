<?php

$ime = "Branko";
$godine = 30;
$grad = "Kragujevac"; 

if ($godine >= 18){
    echo "Osoba je punoletna";
}

else if ($godine <= 18){
    echo "Osoba nije punoletna";
}

if($godine >= 18 && $grad == "Beograd"){
    echo "Osoba je punoletna i zivi u Beogradu";
}

else if($godine <= 18 && $grad =="Beograd"){
    echo "Osoba je maloletna i zivi u Beogradu";
}

else{
    echo "Niste iz Beograda";
}